# InfoHub-Challenge

Full-stack single-page application (React + Node/Express) that includes:
- Real-time Weather (OpenWeather)
- Currency Converter (INR -> USD/EUR using exchangerate.host)
- Motivational Quote Generator

## Quick start (development)

1. Clone/unzip project and open in VS Code.

### Server
2. Open terminal, go to server:
   ```
   cd InfoHub-Challenge/server
   npm install
   ```
3. Copy `.env.example` to `.env` and add your OpenWeather API key:
   ```
   cp .env.example .env
   # then edit .env and set OPENWEATHER_KEY
   ```
4. Start server (dev):
   ```
   npm run dev
   ```
   Server runs on port 3001.

### Client
5. In a new terminal, go to client:
   ```
   cd InfoHub-Challenge/client
   npm install
   npm run dev
   ```
   Vite dev server runs on http://localhost:5173 and proxies `/api` to the server.

## Build / Deploy
- For production you can build the client and serve via any static host.
- Ensure API endpoints are reachable from deployed client (update proxy or API base URL).

## Notes
- Weather requires an OpenWeather API key. Get one at https://openweathermap.org/api and place it in `server/.env` as `OPENWEATHER_KEY`.
- Currency uses free exchangerate.host API (no key).
